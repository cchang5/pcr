import os
import subprocess
import tools

def wrangle_bar(cfg_i, cfg_f, srcQ, snkQ, pix, piy, out_data_file):
    
    for cfg in range(cfg_i, cfg_f+1, 5):
        
        data_dir = '/p/lscratchd/chang49/pcr/charge/bar/'
        with tools.cd(data_dir):
            bar_sdb_file = data_dir+'bar_c'+str(cfg)+'.sdb'
            
            ### only proceed if sdb file exists
            #exists = True
            #try:
            #    if os.stat(bar_sdb_file).st_size == 0:
            #        exists = False
            #except OSError:
            #    exists = False
            #if exists:
            #     subprocess.call("/global/homes/b/bouchard/bin/dbutil "+bar_sdb_file+" keysxml keys.xml", shell=True)
            #     subprocess.call("/global/homes/b/bouchard/bin/dbutil "+bar_sdb_file+" get keys.xml", shell=True)
            subprocess.call("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil "+bar_sdb_file+" keysxml keys.xml", shell=True)
            subprocess.call("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil "+bar_sdb_file+" get keys.xml", shell=True)
            
            for srcSM in ['S']: #, 'P']:
                for snkSM in ['S']: #, 'P']:
                    for piz in [0]: #, -1, 1, -2, 2]:
                        for x in ['0']: #range(-15,17):
                            data_tag = 'bar_'+srcSM+srcQ+'src_'+snkSM+snkQ+'snk_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)
                    
                            #Nucleon-G1g_2_r1-S,0,1,1,1,1,1,0,0,0.Nucleon-G1g_2_r1-S,0.px0_py0_pz2.m0.5455_m0.5455_m0.5455.n3.dat
                            in_data_file = 'Nucleon-G1g_'+srcQ+'_r1-'+srcSM+',0,1,1,1,1,1,0,0,0.Nucleon-G1g_'+snkQ+'_r1-'+snkSM+',0,'+str(x)+'.px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'.m-0.2800_m-0.2800_m-0.2800.n3.dat'

                            fin = open(data_dir+'EDB/ENS/'+in_data_file, 'r')
                            lines = fin.readlines()
                            fin.flush()
                            fin.close()
                            
                            real = [data_tag+'_re']
                            imag = [data_tag+'_im']
                            for j in range(1, len(lines)):
                                temp = lines[j].split()
                                real.append(temp[1])
                                imag.append(temp[2])
                            real.append('\n')
                            imag.append('\n')
                            
                            output1 = ' '.join(['%s' % el for el in real])
                            output2 = ' '.join(['%s' % el for el in imag])
                            fout = open(out_data_file, 'a')
                            fout.write(output1)
                            fout.write(output2)
                            fout.close()
                        
