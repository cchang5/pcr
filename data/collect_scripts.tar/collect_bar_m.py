import subprocess
import tools

def wrangle_bar_m(cfg_i, cfg_f, srcQ, snkQ, pix, piy, moment, out_data_file):
    
    for cfg in range(cfg_i, cfg_f+1, 5):        
        data_dir = '/global/cscratch1/sd/bouchard/data/bar_m'+moment+'/'+str(cfg)+'/'
        with tools.cd(data_dir):
            bar_sdb_file = data_dir+'bar_m'+moment+'_c'+str(cfg)+'.sdb'
            subprocess.call("/global/homes/b/bouchard/bin/dbutil "+bar_sdb_file+" keysxml keys.xml", shell=True)
            subprocess.call("/global/homes/b/bouchard/bin/dbutil "+bar_sdb_file+" get keys.xml", shell=True)
        
        for piz in [0, 1, -1, 2, -2]:
            for srcSM in ['S', 'P']:
                for snkSM in ['S', 'P']:
                    
                    data_tag = 'bar_m'+moment+'_'+srcSM+srcQ+'src_'+snkSM+snkQ+'snk_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)
                    
                    #Nucleon-G1g_2_r1-S,0,1,1,1,1,1,0,0,0.Nucleon-G1g_2_r1-P,0,2,2.px0_py0_pz-1.m0.5455_m0.5455_m0.5455.n3.dat
                    moment_wc = moment[0]
                    for i in range(1,len(moment)):
                        moment_wc += ','+moment[0]
                    
                    in_data_file = 'Nucleon-G1g_'+srcQ+'_r1-'+srcSM+',0,1,1,1,1,1,0,0,0.Nucleon-G1g_'+snkQ+'_r1-'+snkSM+',0,'+moment_wc+'.px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'.m0.5455_m0.5455_m0.5455.n3.dat'
                    
                    fin = open(data_dir+in_data_file, 'r')
                    lines = fin.readlines()
                    fin.flush()
                    fin.close()
                    
                    real = [data_tag+'_re']
                    imag = [data_tag+'_im']
                    for j in range(1, len(lines)):
                        temp = lines[j].split()
                        real.append(temp[1])
                        imag.append(temp[2])
                    real.append('\n')
                    imag.append('\n')
                    
                    output1 = ' '.join(['%s' % el for el in real])
                    output2 = ' '.join(['%s' % el for el in imag])
                    fout = open(out_data_file, 'a')
                    fout.write(output1)
                    fout.write(output2)
                    fout.close()
