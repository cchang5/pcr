import subprocess
import os
import tools
import numpy as np

### script to run dbutil on sdb files, then process text files and collect correlator data in format for:
### - running Peter's fitting script along spatial directions
### - plotting temporal and spatial dependence

def wrangle_bar_s(cfg_i, cfg_f, srcQ, snkQ, pix, piy, moment, out_data_file, tsrc, ensemble, stream):
    Ns = int(ensemble[:2]) #spatial size of lattice
    Nt = int(ensemble[2:]) #temporal size of lattice
    Ncfg = int((cfg_f - cfg_i) / 10.0 + 1)
    #data_dir = '/p/lscratchh/chang49/pcr/charge_%s/%s/bar' %(ensemble,stream)
    #xml_dir = '/p/lscratchh/chang49/pcr/charge_%s/%s/bar/xml_%s' %(ensemble, stream, str(tsrc))
    data_dir = '/p/lscratchh/chang49/pcr/charge_%s/bar' %(ensemble)
    xml_dir = '/p/lscratchh/chang49/pcr/charge_%s/bar/xml_%s' %(ensemble, str(tsrc))
    subprocess.call("mkdir %s" %xml_dir, shell=True)
    for cfg in range(cfg_i, cfg_f+1, 10):
        #if cfg == 1930: continue
        ### need a counter of cfg numbers: 0 ... Ncfg-1
        cntr_cfg = int((cfg - cfg_i) / 10.0)

        ### change to directory for this cfg, generate text data files, then return to initial directory
        try:
            with tools.cd(xml_dir):
                ### run dbutil command to generate text data files from sdb files
                ### * only run dbutil if it hasn't already been done
                #if not os.path.isfile(data_dir+'keys.xml'):
                bar_sdb_file = "%s/bar_s%s_moments_tsrc_%s.sdb%s" %(data_dir,str(moment),str(tsrc),str(cfg))
                print("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil %s keysxml keys.xml" %(bar_sdb_file))
                subprocess.call("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil %s keysxml keys.xml" %(bar_sdb_file), shell=True)
                subprocess.call("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil %s get keys.xml" %(bar_sdb_file), shell=True)
        except:
            continue
        try:
            ### loop over srcSM, snkSM, piz
            for srcSM in ['S']: #, 'P']:
                for snkSM in ['S']: #, 'P']:
                    for piz in [0, -1, 1, -2, 2]:
                        
                        ### array for averaging over cfgs and plotting
                        holder_re = np.zeros((Ncfg, Nt, Ns), float)
                        holder_im = np.zeros((Ncfg, Nt, Ns), float)
                        
                        ### need to specify tslice for which space-dep is being studied (happens below)
                        data_tag = str(cfg)+'_bar_s'+str(moment)+'_'+srcSM+srcQ+'src_'+snkSM+snkQ+'_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)
                        #data_tag = 'bar_s'+str(moment)+'_'+srcSM+srcQ+'src_'+snkSM+snkQ+'_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)
                        #out_plot_file = '/global/homes/b/bouchard/bar_s'+dir+'_'+srcSM+srcQ+snkSM+snkQ+'_piz'+str(piz)+'_plot.dat'
                        #subprocess.call("touch "+out_data_file, shell=True)  #create if doesn't exist, else upates date
                        
                        ### for each spatial slice, collect data vs time (this is how the data are output)
                        for space in range(int(-Ns/2+1),int(Ns/2+1),1):
                            in_data_file = 'Nucleon-G1g_'+srcQ+'_r1-'+srcSM+',0,1,1,1,1,1,0,0,0.Nucleon-G1g_'+snkQ+'_r1-'+snkSM+',0,'+str(space)+'.px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'.m-0.2800_m-0.2800_m-0.2800.n3.dat'
                            #in_data_file = 'Nucleon-G1g_'+srcQ+'_r1-'+srcSM+',0,1,1,1,1,1,0,0,0.Nucleon-G1g_'+snkQ+'_r1-'+snkSM+',0,'+dir+','+str(space)+'.px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'.m0.5455_m0.5455_m0.5455.n3.dat'
                            
                            fin = open("%s/%s" %(xml_dir,in_data_file), 'r')
                            lines = fin.readlines()
                            fin.flush()
                            fin.close()
                            
                            for j in range(1, len(lines)): #skip first line, e.g. '1 64 1 0 1\n'
                                temp = lines[j].split() #turns line into list of strings, e.g. ['0', '8.02945e-21', '-1.29618e-20']
                                holder_re[cntr_cfg][int(temp[0])][space] = float(temp[1])
                                holder_im[cntr_cfg][int(temp[0])][space] = float(temp[2])
                            #closes loop over: j
                        #closes loop over:  space
                                
                        ### for each timeslice, output data along direction specified by dir
                        for time in range(Nt):
                            ### holder_re and holder_im contain data slices I want
                            s_real = [data_tag+'_t'+str(time)+'_re']
                            s_imag = [data_tag+'_t'+str(time)+'_im']
                            for space in range(Ns):
                                s_real.append(str(holder_re[cntr_cfg][time][space]))
                                s_imag.append(str(holder_im[cntr_cfg][time][space]))
                            s_real.append('\n')
                            s_imag.append('\n')
                            
                            output1 = ' '.join(['%s' % el for el in s_real])
                            output2 = ' '.join(['%s' % el for el in s_imag])
                            fout = open(out_data_file+'.re', 'a')
                            fout.write(output1)
                            fout.close()
                            fout = open(out_data_file+'.im', 'a')
                            fout.write(output2)
                            fout.close()
                        #closes loop over:  time
                        
                        """
                        ### For plotting, compute mean and std dev over configurations
                        avg_re = np.mean(holder_re, axis=0)
                        avg_im = np.mean(holder_im, axis=0)
                        std_re = np.std(holder_re, axis=0)
                        std_im = np.std(holder_im, axis=0)
                        ### write out in format for plotting
                        fout = open(out_plot_file, 'w')
                        fout.write('#1:t  2:s  3:Re  4:err  5:Im  6:err\n')
                        for t in range(Nt):
                            for s in range(Ns):
                                fout.write(str(t)+' '+str(s)+' '+str(avg_re[t][s])+' '+str(std_re[t][s])+' '+str(avg_im[t][s])+' '+str(std_im[t][s])+'\n')
                            fout.write('\n')
                        fout.close()
                        """
                    #closes loop over:  piz
        except:
            continue
        subprocess.call("rm %s/*" %xml_dir, shell=True)
