import subprocess
import tools

def wrangle_barff_m(cfg_i, cfg_f, srcQ, snkQ, Tee, pix, piy, gammaLIST, moment, out_data_file):

    subprocess.call("touch "+out_data_file, shell=True)

    for cfg in range(cfg_i, cfg_f+1, 5):
        data_dir = '/global/cscratch1/sd/bouchard/data/barff_m'+moment+'/'+str(cfg)+'/'

        for smear in ['SHELL', 'POINT']:
            ### change to directory for this cfg, generate text data files, then return to initial directory
            with tools.cd(data_dir):
                ### run dbutil command to generate text data files from sdb files
                barff_sdb_file = data_dir+'barff_m'+moment+'_T'+Tee+'_c'+str(cfg)+'_'+smear[0]+smear[0]+'.sdb'
                subprocess.call("/global/homes/b/bouchard/bin/dbutil "+barff_sdb_file+" keysxml keys.xml", shell=True)
                subprocess.call("/global/homes/b/bouchard/bin/dbutil "+barff_sdb_file+" get keys.xml", shell=True)

            for gamma in gammaLIST:
                for piz in [0, -1, 1, -2, 2]:
                
                    data_tag = 'barff_m'+moment+'_'+smear[0]+srcQ+'src_'+smear[0]+snkQ+'snk_T'+str(Tee)+'_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'_g'+str(gamma)

                    ### moment 22 given in data_file by l2_2_2; l2 means length=2
                    moment_str = moment[0]
                    for i in range(1, len(moment)):
                        moment_str += '_' + moment[i]
                    in_data_file = 'G1g_'+srcQ+'_r1-'+smear+'_SOURCE '+smear+'_SOURCE '+smear+'_SOURCE,1.G1g_'+snkQ+'_r1-'+smear+'_SINK '+smear+'_SINK '+smear+'_SINK,1.q0.g'+str(gamma)+'.l'+str(len(moment))+'_'+moment_str+'.pix'+str(pix)+'_piy'+str(piy)+'_piz'+str(piz)+'.pfx0_pfy0_pfz0.0.545455 [0.545455 0.545455 0.545455].n3.dat'
                    fin = open(data_dir+in_data_file, 'r')
                    lines = fin.readlines()
                    fin.flush()
                    fin.close()
                    
                    real = [data_tag+'_re']
                    imag = [data_tag+'_im']
                    for j in range(1, len(lines)): #skip first line, e.g. '1 64 1 0 1\n'
                        temp = lines[j].split() #turns line into list of strings, e.g. ['0', '8.02945e-21', '-1.29618e-20']
                        real.append(temp[1])
                        imag.append(temp[2])
                    real.append('\n')
                    imag.append('\n')
                    
                    ### write each list of strings (real and imag) as a row in an output data file
                    output1 = ' '.join(['%s' % el for el in real])
                    output2 = ' '.join(['%s' % el for el in imag])
                    fout = open(out_data_file, 'a')
                    fout.write(output1)
                    fout.write(output2)
                    fout.close()
