import subprocess
import os
import tools
import numpy as np

### script to run dbutil on sdb files, then process text files and collect correlator data in format for:
### - running Peter's fitting script on temporal and spatial directions
### - plotting temporal and spatial dependence

def wrangle_barff_s(cfg_i, cfg_f, srcQ, snkQ, Tee, pix, piy, gammaLIST, moment, out_data_file, tsrc, isospin, ensemble, stream):
    
    dir = moment[0]
    #data_dir = '/p/lscratchh/chang49/pcr/charge_%s/%s/barff' %(ensemble,stream)
    #if isospin in ['up']:
    #    xml_dir = '/p/lscratchh/chang49/pcr/charge_%s/%s/barff/xml_%s_%s' %(str(ensemble),str(stream),str(tsrc),str(Tee)) # UP QUARK FOLDER
    #elif isospin in ['dn']:
    #    xml_dir = '/p/lscratchh/chang49/pcr/charge_%s/%s/barff/xml_down_%s_%s' %(str(ensemble),str(stream),str(tsrc),str(Tee)) # DOWN QUARK FOLDER
    data_dir = '/p/lscratchh/chang49/pcr/charge_%s/barff' %(ensemble)
    if isospin in ['up']:
        xml_dir = '/p/lscratchh/chang49/pcr/charge_%s/barff/xml_%s_%s' %(str(ensemble),str(tsrc),str(Tee)) # UP QUARK FOLDER
    elif isospin in ['dn']:
        xml_dir = '/p/lscratchh/chang49/pcr/charge_%s/barff/xml_down_%s_%s' %(str(ensemble),str(tsrc),str(Tee)) # DOWN QUARK FOLDER
    print("xml_dir:", xml_dir)
    subprocess.call("mkdir %s" %xml_dir, shell=True)
    Ns = int(ensemble[:2]) #spatial size of lattice
    Nt = int(ensemble[2:]) #temporal size of lattice
    print(Ns, Nt)
    Ncfg = int((cfg_f - cfg_i) / 10.0 + 1)

    for cfg in range(cfg_i, cfg_f+1, 10):
        if cfg == 1930: continue
        ### need a counter of cfg numbers: 0 ... Ncfg-1
        cntr_cfg = int((cfg - cfg_i) / 10.0)
        
        ### change to directory for this cfg, generate text data files, then return to initial directory
        for smear in ['SHELL']: #['POINT', 'SHELL']:
            try:
                with tools.cd(xml_dir):
                    ### run dbutil command to generate text data files from sdb files
                    ### * would be good to limit the creation of files to only the g=4,11
                    ### * only run dbutil if it hasn't already been done
                    #if not os.path.isfile(data_dir+'keys.xml') or True:
                    # barff_s22_tsrc_0_tsink_14.sdb1560
                    # barff_s22_tsrc_48_tsink_14.sdb2850
                    if isospin in ['up']:
                        barff_sdb_file = '%s/barff_s%s_tsrc_%s_tsink_%s.sdb%s' %(data_dir,moment,tsrc,Tee,str(cfg)) # UP QUARK CONTRIBUTION
                    elif isospin in ['dn']:
                        barff_sdb_file = '%s/barff_s%s_down_tsrc_%s_tsink_%s.sdb%s' %(data_dir,moment,tsrc,Tee,str(cfg)) # DOWN QUARK CONTRIBUTION
                    subprocess.call("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil %s keysxml keys.xml" %barff_sdb_file, shell=True)
                    subprocess.call("/g/g17/chang49/c51/x_files/project_2/data_management/bin/dbutil %s get keys.xml" %barff_sdb_file, shell=True)
                    print("READ")
            except:
                continue
            
            try:
                for gamma in gammaLIST:
                    for piz in [0, -1, 1, -2, 2]:
                        
                        ### arrays for averaging over cfgs and plotting
                        holder_re = np.zeros((Ncfg, Nt, Ns), float)
                        holder_im = np.zeros((Ncfg, Nt, Ns), float)
                        
                        data_tag = str(cfg)+'_barff_s'+str(dir)+'_'+smear[0]+srcQ+'src_'+smear[0]+snkQ+'snk_T'+str(Tee)+'_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'_g'+str(gamma)
                        #data_tag = 'barff_s'+str(dir)+'_'+smear[0]+srcQ+'src_'+smear[0]+snkQ+'snk_T'+str(Tee)+'_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'_g'+str(gamma)
                        #out_plot_file = '/global/homes/b/bouchard/'+data_tag+'_Ncfg'+str(Ncfg)+'.dat'

                        for space in range(int(-1*Ns/2+1),int(Ns/2+1),int(1)):
                            if isospin in ['up']:
                                in_data_file = 'G1g_'+srcQ+'_r1-'+smear+'_SOURCE '+smear+'_SOURCE '+smear+'_SOURCE,1.G1g_'+snkQ+'_r1-'+smear+'_SINK '+smear+'_SINK '+smear+'_SINK,1.q0.g'+str(gamma)+'.l1_'+str(space)+'.pix'+str(pix)+'_piy'+str(piy)+'_piz'+str(piz)+'.pfx0_pfy0_pfz0.-0.28 [-0.28 -0.28 -0.28].n3.dat'
                            elif isospin in ['dn']:
                                in_data_file = 'G1g_'+srcQ+'_r1-'+smear+'_SOURCE '+smear+'_SOURCE '+smear+'_SOURCE,1.G1g_'+snkQ+'_r1-'+smear+'_SINK '+smear+'_SINK '+smear+'_SINK,1.q1.g'+str(gamma)+'.l1_'+str(space)+'.pix'+str(pix)+'_piy'+str(piy)+'_piz'+str(piz)+'.pfx0_pfy0_pfz0.-0.28 [-0.28 -0.28 -0.28].n3.dat'
                            # DOWN QUARK CONTRIBUTION POSSIBLY OFF BY A q0 VS q1
                            fin = open("%s/%s" %(xml_dir,in_data_file), 'r')
                            lines = fin.readlines()
                            fin.flush()
                            fin.close()
                            
                            for j in range(1, int(len(lines))): #skip first line, e.g. '1 64 1 0 1\n'
                                temp = lines[j].split() #turns line into list of strings, e.g. ['0', '8.02945e-21', '-1.29618e-20']
                                holder_re[cntr_cfg][int(temp[0])][space] = float(temp[1])
                                holder_im[cntr_cfg][int(temp[0])][space] = float(temp[2])
                            #closes loop over: j
                        #closes loop over:  space
                    
                        ### for each timeslice, output data along direction specified by dir
                        for time in range(int(Nt)):
                            ### holder_re and holder_im contain data slices I want
                            s_real = [data_tag+'_t'+str(time)+'_re']
                            s_imag = [data_tag+'_t'+str(time)+'_im']
                            for space in range(int(Ns)):
                                s_real.append(str(holder_re[cntr_cfg][time][space]))
                                s_imag.append(str(holder_im[cntr_cfg][time][space]))
                            s_real.append('\n')
                            s_imag.append('\n')
                            
                            output1 = ' '.join(['%s' % el for el in s_real])
                            output2 = ' '.join(['%s' % el for el in s_imag])
                            fout = open("%s.re" %out_data_file, 'a')
                            fout.write(output1)
                            fout.close()
                            fout = open("%s.im" %out_data_file, 'a')
                            fout.write(output2)
                            fout.close()
                        #closes loop over:  time
                    #closes loop over:  piz
                #closes loop over:  gamma
            except:
                continue
        #closes loop over:  smear
        subprocess.call("rm %s/*" %xml_dir, shell=True)
    #closes loop over:  config

    """
    ### calculate mean and std dev over configurations
    avg_re = np.mean(holder_re, axis=0)
    avg_im = np.mean(holder_im, axis=0)
    std_re = np.std(holder_re, axis=0)
    std_im = np.std(holder_im, axis=0)
    
    ### write out in format for plotting
    fout = open(out_plot_file, 'w')
    fout.write('#1:t  2:s  3:Re  4:err  5:Im  6:err\n')
    for t in range(Nt):
        for s in range(Ns):
            fout.write(str(t)+' '+str(s)+' '+str(avg_re[t][s])+' '+str(std_re[t][s])+' '+str(avg_im[t][s])+' '+str(std_im[t][s])+'\n')
        fout.write('\n')
    fout.close()
    """
