import subprocess
import collect_mes as cmes
import collect_bar as cbar
import collect_bar_m as cbar_m
import collect_bar_s as cbar_s
import collect_barff as cbarff
import collect_barff_m as cbarff_m
import collect_barff_s as cbarff_s
import gen_barff_m as gbarff_m

### run dbutil on sdb files, process text files to collect correlator data in format for lsqfit

ensemble = '4896' # '3296' or '4896'

### cfgs to process
if ensemble in ['3296']:
    cfg_i = 1000
    cfg_f = 2950
elif ensemble in ['4896']:
    cfg_i = 1370
    cfg_f = 2390

### used for bar_m, bar_s, barff_m, and barff_s
moment = '22'

### source and sink smearing: POINT, SHELL (loop over)
srcQ = '0'
snkQ = '0'

### source-sink temporal separation
#Tee = '8'
Tee = '10'
#Tee = '14'
#tsrc = 0
tsrc = 48
### initial momentum: -1, 0, 1 (I thought we'd only have pz?)
pix = 0
piy = 0

### g(amma matrices) 0-15: 4=gamma_3, 11=gamma_3*gamma_5, 8=gamma_4, 7=gamma_4*gamma_5
gammaLIST = [8]
#gammaLIST = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

# UU or DD for 3pt
isospin = 'up' # 'dn' or 'up'

stream = 'b' # for 4896 only

### NEED TO PUT IN A LOOP OVER SOURCES.
### THE LOOP IS FOR A GIVEN CFG, SO IT SHOULD GO INSIDE THE FNS CALLED BELOW.

### meson (SS, SP, PS, PP; g3, g35, g5, g45; piz= +-2, +-1, 0)
#cmes.wrangle_mes(cfg_i, cfg_f, pix, piy, out_data_file)

### baryon 2pt spatial dependence (SS, SP, PS, PP): missing quite a few data files
# Changing source/sink need to change corresponding source/sink in collect_bar_s.py file
out_data_file = '/p/lscratchd/chang49/pcr/ascii/bar_s22_SS_tsrc_%s_%s.dat' %(tsrc,stream)
cbar_s.wrangle_bar_s(cfg_i, cfg_f, srcQ, snkQ, pix, piy, moment, out_data_file, tsrc,ensemble,stream)

### baryon form factor 3pt spatial dependence
#if isospin in ['up']:
#    out_data_file = '/p/lscratchd/chang49/pcr/ascii/barff_s22_SS_g%s_T%s_tsrc_%s_%s.dat' %(gammaLIST[0],Tee,tsrc,stream)
#elif isospin in ['dn']:
#    out_data_file = '/p/lscratchd/chang49/pcr/ascii/barff_s22_SS_down_g%s_T%s_tsrc_%s_%s.dat' %(gammaLIST[0],Tee,tsrc,stream)
#cbarff_s.wrangle_barff_s(cfg_i, cfg_f, srcQ, snkQ, Tee, pix, piy, gammaLIST, moment, out_data_file, tsrc, isospin, ensemble, stream)

