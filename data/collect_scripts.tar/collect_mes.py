import os
import subprocess
import tools

def wrangle_mes(cfg_i, cfg_f, pix, piy, out_data_file):

    for cfg in range(cfg_i, cfg_f+1, 5):
        
        data_dir = '/global/cscratch1/sd/bouchard/data/mes/'+str(cfg)+'/'
        ### change to directory for this cfg, generate text data files, then return to initial directory
        with tools.cd(data_dir):
            
            ### run dbutil command to generate text data files from sdb files
            mes_sdb_file = data_dir+'mes_'+str(cfg)+'.sdb'
            
            ### only proceed if sdb file exists
            #exists = True
            #try:
            #    if os.stat(mes_sdb_file).st_size == 0:
            #        exists = False
            #except OSError:
            #    exists = False
            #if exists:
            #    subprocess.call("/global/homes/b/bouchard/bin/dbutil "+mes_sdb_file+" keysxml keys.xml", shell=True)
            #    subprocess.call("/global/homes/b/bouchard/bin/dbutil "+mes_sdb_file+" get keys.xml", shell=True)
            subprocess.call("/global/homes/b/bouchard/bin/dbutil "+mes_sdb_file+" keysxml keys.xml", shell=True)
            subprocess.call("/global/homes/b/bouchard/bin/dbutil "+mes_sdb_file+" get keys.xml", shell=True)
            
            for gamma in ['5', '45', '3', '35']:  #<-- still need to generate g3 and g35 data for all cfgs?
                for piz in [0, -1, 1, -2, 2]:
                    for srcSM in ['S', 'P']:
                        for snkSM in ['S', 'P']:
                            
                            data_tag = 'mes_g'+gamma+'_'+srcSM+'src_'+snkSM+'snk_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)

                            ### read in data file
                            in_data_file = 'pion-g'+gamma+'-'+srcSM+',0,1,0,0,1,1,0,0,0.pion-g'+gamma+'-'+snkSM+',0.px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'.m0.5455_m0.5455.n3.dat'
                            fin = open(data_dir+in_data_file, 'r')
                            lines = fin.readlines()
                            fin.flush()
                            fin.close()
                            
                            real = [data_tag+'_re']
                            imag = [data_tag+'_im']
                            
                            for j in range(1, len(lines)): #skip first line, e.g. '1 64 1 0 1\n'
                                temp = lines[j].split() #turns line into list of strings, e.g. ['0', '8.02945e-21', '-1.29618e-20']
                                real.append(temp[1])
                                imag.append(temp[2])
                            real.append('\n')
                            imag.append('\n')
                            
                            ### write each list of strings (real and imag) as a row in an output data file
                            output1 = ' '.join(['%s' % el for el in real])
                            output2 = ' '.join(['%s' % el for el in imag])
                            fout = open(out_data_file, 'a')
                            fout.write(output1)
                            fout.write(output2)
                            fout.close()
