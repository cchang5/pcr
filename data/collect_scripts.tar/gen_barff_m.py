import subprocess
import os
import tools
import numpy as np

### script to run dbutil on sdb files, then process text files and collect correlator data in format for:
### - running Peter's fitting script on temporal and spatial directions
### - plotting temporal and spatial dependence

def gen_barff_m(cfg_i, cfg_f, srcQ, snkQ, Tee, pix, piy, gammaLIST, moment, out_data_file):
    
    dir = moment[0]
    subprocess.call("touch "+out_data_file, shell=True)

    Ns = 24 #spatial size of lattice
    Nt = 64 #temporal size of lattice
    Ncfg = int((cfg_f - cfg_i) / 5.0 + 1)

    for cfg in range(cfg_i, cfg_f+1, 5):
        ### need a counter of cfg numbers: 0 ... Ncfg-1
        cntr_cfg = int((cfg - cfg_i) / 5.0)
        
        ### change to directory for this cfg, generate text data files, then return to initial directory
        data_dir = '/global/cscratch1/sd/bouchard/data/barff_s22_T10/'+str(cfg)+'/'

        for smear in ['POINT', 'SHELL']:
            #with tools.cd(data_dir):
                ### run dbutil command to generate text data files from sdb files
                ### * would be good to limit the creation of files to only the g=4,11
                ### * only run dbutil if it hasn't already been done
                #barff_sdb_file = data_dir+'barff_s'+moment+'_T'+Tee+'_c'+str(cfg)+'_'+smear[0]+smear[0]+'.sdb'
                #subprocess.call("/global/homes/b/bouchard/bin/dbutil "+barff_sdb_file+" keysxml keys.xml", shell=True)
                #subprocess.call("/global/homes/b/bouchard/bin/dbutil "+barff_sdb_file+" get keys.xml", shell=True)

            for gamma in gammaLIST:
                for piz in [0, -1, 1, -2, 2]:
                    
                    ### arrays for averaging over cfgs and plotting
                    holder_re = np.zeros((Ncfg, Nt, Ns), float)
                    holder_im = np.zeros((Ncfg, Nt, Ns), float)
                    
                    data_tag = 'barff_m'+moment+'_'+smear[0]+srcQ+'src_'+smear[0]+snkQ+'snk_T'+str(Tee)+'_px'+str(pix)+'_py'+str(piy)+'_pz'+str(piz)+'_g'+str(gamma)

                    for space in range(Ns):
                        in_data_file = 'G1g_'+srcQ+'_r1-'+smear+'_SOURCE '+smear+'_SOURCE '+smear+'_SOURCE,1.G1g_'+snkQ+'_r1-'+smear+'_SINK '+smear+'_SINK '+smear+'_SINK,1.q0.g'+str(gamma)+'.l1_'+str(space)+'.pix'+str(pix)+'_piy'+str(piy)+'_piz'+str(piz)+'.pfx0_pfy0_pfz0.0.545455 [0.545455 0.545455 0.545455].n3.dat'
                        fin = open(data_dir+in_data_file, 'r')
                        lines = fin.readlines()
                        fin.flush()
                        fin.close()
                        
                        for j in range(1, len(lines)): #skip first line, e.g. '1 64 1 0 1\n'
                            temp = lines[j].split() #turns line into list of strings, e.g. ['0', '8.02945e-21', '-1.29618e-20']
                            holder_re[cntr_cfg][int(temp[0])][space] = float(temp[1])
                            holder_im[cntr_cfg][int(temp[0])][space] = float(temp[2])
                        #closes loop over: j
                    #closes loop over:  space
             
                    ### for each timeslice sum over z, with moment
                    s_real = [data_tag+'_re']
                    s_imag = [data_tag+'_im']
                    for time in range(Nt):
                        tmp_re = 0.0
                        tmp_im = 0.0
                        for space in range(Ns):
                            tmp_re += holder_re[cntr_cfg][time][space] * space**(len(moment))
                            tmp_im += holder_im[cntr_cfg][time][space] * space**(len(moment))
                        s_real.append(str(tmp_re))
                        s_imag.append(str(tmp_im))
                    #closes loop over:  time
                    s_real.append('\n')
                    s_imag.append('\n')

                    output1 = ' '.join(['%s' % el for el in s_real])
                    output2 = ' '.join(['%s' % el for el in s_imag])
                    fout = open(out_data_file, 'a')
                    fout.write(output1)
                    fout.write(output2)
                    fout.close()
                    
                #closes loop over:  piz
            #closes loop over:  gamma
        #closes loop over:  smear
    #closes loop over:  config
